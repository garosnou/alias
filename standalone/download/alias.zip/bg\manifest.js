// Список картинок в папке bg для экрана зала (можно править в блокноте).
// Пересобрать автоматически: node scripts/gen-bg-manifest.js
window.ALIAS_BG_MANIFEST = [];
